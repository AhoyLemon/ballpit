[table]
[tr]
[td]
[color=#006400][size=16pt][b]BBC [you] Tag[/b][/size][/color]
This modification adds a BBC tag that allows users to echo out the name of the user who is reading the topic.
[iurl=http://custom.simplemachines.org/mods/index.php?mod=1224]Link to Mod[/iurl] | [iurl=http://www.simplemachines.org/community/index.php?action=post;topic=242344.0]Comment On This Mod[/iurl]

[b]Updated on:[/b] 20th July 2012
[b]Current Author:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=254071]Diego Andr�s[/url]
[/td]
[td]
[b]Author:[/b] [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=227037]Dream Portal[/url]
[b]Original creator:[/b] [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=111571]ccbtimewiz[/url]
[b]Type:[/b] [url=http://custom.simplemachines.org/mods/index.php?action=search;type=6]BBC[/url]
[b]Available since:[/b] 31th May 2008
[b]Latest version:[/b] 1.3
[b]Compatible with:[/b] SMF 2.0, SMF 2.0.1, SMF 2.0.2
[b]Available languages:[/b] [size=1][img]http://www.simplemachines.org/site_images/lang/english.gif[/img][/size]
[/td]
[/tr]
[/table]
[hr]

[color=#228B22][b][size=12pt]What does it do?[/size][/b][/color]
[i]BBC [you] Tag[/i] adds a BBC tag that allows users to echo out the name of the user who is reading the topic.

[color=#228B22][b][size=12pt]How to use[/size][/b][/color]
To use [i]PM Informer[/i], [url=http://custom.simplemachines.org/mods/index.php?mod=1224]download the package from the SMF customization site[/url], and install it via your [url=http://docs.simplemachines.org/index.php?topic=95]Package Manger[/url].
It should add a new BBC in your forum, that will allow users to echo out the name of the user whoe is reading the topic.

[size=1][color=maroon][b]*[/b][/color] = No settings to set up[/size]

[color=#228B22][b][size=12pt]Support & comments[/b][/color]
If you have a problem with this mod, want to comment, or have any question, please [url=http://www.simplemachines.org/community/index.php?action=post;topic=242344.0]post to the modification support topic[/url] and I will reply as soon as possible.

[color=#228B22][b][size=12pt]Other information[/size][/b][/color]
[b]Translation of this mod[/b]
o I am always happy to get translations of my work so that more users can use it. If you have translated this modification, please [url=http://www.simplemachines.org/community/index.php?action=post;topic=242344.0]post the translation in the support topic[/url]. 
Please make sure you have translated everything, and that there are no spelling misstakes etc.
Also, please post both a non-UTF8 version and a UTF8 version.
[b]Credits[/b]
o Thanks [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=111571]ccbtimewiz[/url], the original creator.

[color=#228B22][b][size=12pt]Changelog[/size][/b][/color]
[size=7pt][color=brown]$[/color] BBC [you] Tag taken over by Diego Andr�s[/size]

[hr]
[table]
[tr]
[td][b]Changelog legend[/b]
[color=green]+[/color] New feature
[color=red]-[/color] Feature removal
[color=limeGreen]![/color] Bugfix
[color=blue]>[/color] New language
[color=orange]<[/color] Removed language
[color=pink]*[/color] New version support
[color=brown]$[/color] Initial release / Big update[/td]
[td]
[b]Versionnames[/b]
[i]Format: $.o.x.![/i]
[i]Example: 3.2.4.1[/i]

$ New version
o New features added
x Bugfix
! Small bugfix / New version support

[/td]
[td]
[b]Passed versions of this mod[/b]
2.0.2
2.0.1
2.0
[/td]
[/tr]
[/table]
[hr]