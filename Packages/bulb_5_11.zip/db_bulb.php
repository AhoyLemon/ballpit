<?php
	global $smcFunc, $db_prefix, $context, $modSettings;
	
	// Define the Manual Installation Status
    $manual_install = false;

	if (!defined('SMF'))
		die('Installer wasn\'t able to connect to SMF!');
		
	db_extend('packages');
	
	$columns = array(
	array(
		'name' => 'id_message',
		'type' => 'int',
		'size' => '11',
		'default' => '0',
		'null' => false,
	),
	array(
		'name' => 'id_voter',
		'type' => 'int',
		'size' => '11',
		'default' => '0',
		'null' => false,
	),
	array(
		'name' => 'id_poster',
		'type' => 'int',
		'size' => '11',
		'default' => '0',
		'null' => false,
	),
	array(
		'name' => 'id_topic',
		'type' => 'int',
		'size' => '11',
		'default' => '0',
		'null' => false,
	),
	array(
		'name' => 'timestamp',
		'type' => 'int',
		'size' => '11',
		'default' => '0',
		'null' => false,
	),
	array(
		'name' => 'is_removed',
		'type' => 'tinyint',
		'size' => '3',
		'default' => '0',
		'null' => false,
	)
	);
	$smcFunc['db_create_table']('{db_prefix}bulbs', $columns, array());
	
	$smcFunc['db_add_column'] ('{db_prefix}messages', array(
		'name' => 'bulbs_total',
		'type' => 'int',
		'size' => '11',
		'default' => '0',
		'null' => false,
		)
	);
	
	$smcFunc['db_add_column'] ('{db_prefix}members', array(
		'name' => 'bulbs_total',
		'type' => 'int',
		'size' => '11',
		'default' => '0',
		'null' => false,
		)
	);
	


	
	
?>