[hr]
[center][color=red][size=16pt][b]IMAGE THUMBNAIL v1.0[/b][/size][/color]
By Tomahawk
[/center]
[hr]

[color=blue][b][size=12pt]Introduction[/size][/b][/color]
Enables you use bbcode to post large images which will be preview with a link to full image using imgt bbcode

[color=blue][b][size=12pt]Installation[/size][/b][/color]
Installs automatically on Default theme and any theme without a custom Post.template.php

To manually install this modification on other themes;
- place the imgt.gif in the "Themes/{ThemeName}/images/bbc" for EVERY THEME.
- A single manual edit is required FOR EACH THEME with a custom Post.template.php

Open Themes/{themename}/Post.template.php, and FIND:
[code] 
		$context['bbc_tags'][] = array(
			'flash' => array('code' => 'flash', 'before' => '[flash=200,200]', 'after' => '[/flash]', 'description' => $txt[433]),
 [/code]
ADD AFTER:
[code] 
			'imgt' => array('code' => 'imgt', 'before' => '[imgt]', 'after' => '[/imgt]'),
 [/code]

If you are still having trouble, I recommend the [url=http://modparser.dev.dansoftaustralia.net/]Modification Parser[/url] by Daniel 15

[color=blue][b][size=12pt]How Do I Use This Mod?[/size][/b][/color]
This bbcode tag is used like img tag, only this tag will not show full image, but only a preview.

[code]
[imgt]url_to_image[/imgt]
[/code]

[color=blue][b][size=12pt]Support[/b][/color]
Please use the modification thread for support with this modification.
(Please don't ask me to do the edits for you)

[color=blue][b][size=12pt]Changelog[/size][/b][/color]
[b]1.0[/b]
o Initial release
