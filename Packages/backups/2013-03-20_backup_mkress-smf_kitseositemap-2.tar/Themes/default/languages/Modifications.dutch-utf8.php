<?php
// Version: 2.0; Modifications


$txt['youtube'] = 'YouTube';
$txt['youtube_invalid'] = '#geen geldige Youtube Link#';

?>