<?php
// Version: 2.0; Modifications


// Aeva Media extra strings
$txt['aeva_gallery'] = isset($txt['aeva_gallery']) ? $txt['aeva_gallery'] : 'Media';
$txt['aeva_home'] = 'Accueil';
$txt['aeva_unseen'] = '&Agrave;&nbsp;voir';
$txt['aeva_profile_sum'] = 'R&eacute;sum&eacute;';
$txt['aeva_view_items'] = 'Voir les &eacute;l&eacute;ments';
$txt['aeva_view_coms'] = 'Voir les commentaires';
$txt['aeva_view_votes'] = 'Voir les votes';
$txt['aeva_gotolink'] = 'D&eacute;tails';
$txt['aeva_zoom'] = 'Zoom';
$txt['permissiongroup_aeva'] = 'Aeva Media';
$txt['permissiongroup_simple_aeva'] = 'Aeva Media';
$txt['permissionname_aeva_access'] = 'Consulter la Galerie';
$txt['permissionname_aeva_moderate'] = 'Mod&eacute;rer la Galerie';
$txt['permissionname_aeva_manage'] = 'Administrer la Galerie';
$txt['permissionname_aeva_access_unseen'] = 'Voir la liste des &eacute;l&eacute;ments non visit&eacute;s';
$txt['permissionname_aeva_search'] = 'Rechercher des &eacute;l&eacute;ments dans la Galerie';
$txt['permissionname_aeva_add_user_album'] = 'Cr&eacute;er des Albums';
$txt['permissionname_aeva_add_playlists'] = 'Cr&eacute;er des Playlists';
$txt['permissionname_aeva_auto_approve_albums'] = 'Auto-approuver ses Albums';
$txt['permissionname_aeva_moderate_own_albums'] = '<span style="border-bottom: 1px #888 dashed" title="Supprimer tout commentaire/&eacute;l&eacute;ment sur ses albums, et supprimer ses propres albums.">Mod&eacute;rer ses Albums</span>';
$txt['permissionname_aeva_viewprofile'] = 'Voir les profils de Galerie des utilisateurs';
$txt['cannot_aeva_viewprofile'] = 'Vous n\'avez pas l\'autorisation de consulter des profils de Galerie';
// End Aeva Media strings

?>