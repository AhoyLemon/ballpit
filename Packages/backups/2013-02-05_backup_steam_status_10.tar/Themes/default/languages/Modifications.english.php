<?php
// Version: 2.0; Modifications

$txt['steam'] = 'Steam';
$txt['steam_username'] = 'Your Steam Commuity URL <i>http://steamcommunity.com/id/<b>name</b></i>';
$txt['steam_error_noxml'] = 'SimpleXML is not avaiable!<br />This could be because of incorrect PHP version (5 or above).';
$txt['steam_error_unset_id'] = 'User has not been set!';
$txt['steam_error_invaliduser'] = 'That user does not seem to exist!';

?>