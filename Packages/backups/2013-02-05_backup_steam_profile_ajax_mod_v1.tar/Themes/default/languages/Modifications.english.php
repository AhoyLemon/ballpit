<?php
// Version: 2.0; Modifications


// Steam Profile Mod by Roco
$txt['steamprofile'] = 'Steam Profile';
$txt['steamprofile_profile'] = 'Profile';
$txt['steamprofile_user_ID'] = ' or: Steam Community <b>Number</b>, or: Profile <b>Alias</b><br />
Like: <b>76561197965018417</b> or: <b>STEAM_0:0:148902</b> or: <b>robinwalker</b>';
$txt['steamprofile_input_title'] = 'Type Your Steam Profile: ID - here';
$txt['steamprofile_view'] = 'view';
$txt['steamprofile_view_desc'] = 'Your own Profil from Steam Community';
// End of Steam Profile Mod by Roco


?>