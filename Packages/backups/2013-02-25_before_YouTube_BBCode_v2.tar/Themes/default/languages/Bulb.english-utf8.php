<?php
// Version: 2.0.4; Modifications
$txt['bulb_blubs'] = 'Bulbs';
$txt['bulb_bulb'] = 'Bulb';
$txt['bulb_error'] = 'Bulb error generic: Could not process this request';
$txt['bulb_yourself'] = 'Stop trying to bulb yourself, asshole';
$txt['bulb_already_bulbed'] = 'This message is already bulbed, stop trying to game this system dickface';
$txt['bulb_lacks_msg'] = 'Bulb error: message does not exist or belong to topic';
$txt['bulb_msg_not_found'] = 'Bulb error: message not found';
$txt['bulb_msg_not_approved'] = 'Bulb error: message not approved';

?>