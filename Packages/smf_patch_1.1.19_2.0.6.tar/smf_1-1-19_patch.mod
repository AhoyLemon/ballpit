<edit file>
$boarddir/index.php
</edit file>

<search for>
* =============================================================================== *
* Software Version:           SMF 1.1.18                                          *
</search for>

<replace>
* =============================================================================== *
* Software Version:           SMF 1.1.19                                          *
</replace>

<search for>
$forum_version = 'SMF 1.1.18';
</search for>

<replace>
$forum_version = 'SMF 1.1.19';
</replace>

<search for>
// Register an error handler.
</search for>

<replace>
// Emit some headers for some modicum of protection against nasties.
if (!headers_sent())
{
	// Future versions will make some of this configurable. This is primarily a 'safe' configuration for most cases for now.
	header('X-Frame-Options: SAMEORIGIN');
	header('X-XSS-Protection: 1; mode=block');
	header('X-Content-Type-Options: nosniff');
}

// Register an error handler.
</replace>


<edit file>
$sourcedir/Profile.php
</edit file>

<search for>
* =============================================================================== *
* Software Version:           SMF 1.1.11                                          *
</search for>

<replace>
* =============================================================================== *
* Software Version:           SMF 1.1.19                                          *
</replace>

<search for>
				// Now try to find an infection.
				while (!feof($fp))
				{
					if (preg_match('~(iframe|\\<\\?php|\\<\\?[\s=]|\\<%[\s=]|html|eval|body|script\W)~', fgets($fp, 4096)) === 1)
					{
						if (file_exists($uploadDir . '/avatar_tmp_' . $memID))
							@unlink($uploadDir . '/avatar_tmp_' . $memID);

						fatal_lang_error('smf124');
					}
				}
				fclose($fp);
</search for>

<replace>
				// Now try to find an infection.
				$prev_chunk = '';
				while (!feof($fp))
				{
					$cur_chunk = fread($fp, 8192);

					// Paranoid check. Some like it that way.
					if (preg_match('~(iframe|\\<\\?|\\<%|html|eval|body|script\W|[CF]WS[\x01-\x0C])~i', $prev_chunk . $cur_chunk) === 1)
					{
						fclose($fp);
						if (file_exists($uploadDir . '/avatar_tmp_' . $memID))
							@unlink($uploadDir . '/avatar_tmp_' . $memID);

						fatal_lang_error('smf124');
					}

					$prev_chunk = $cur_chunk;
				}
				fclose($fp);
</replace>

<search for>
			$_POST['realName'] = trim(preg_replace('~[\s]~' . ($context['utf8'] ? 'u' : ''), ' ', $_POST['realName']));
</search for>

<replace>
			$_POST['realName'] = trim(preg_replace('~[\t\n\r \x0B\0' . ($context['utf8'] ? ($context['server']['complex_preg_chars'] ? '\x{A0}\x{AD}\x{2000}-\x{200F}\x{201F}\x{202F}\x{3000}\x{FEFF}' : "\xC2\xA0\xC2\xAD\xE2\x80\x80-\xE2\x80\x8F\xE2\x80\x9F\xE2\x80\xAF\xE2\x80\x9F\xE3\x80\x80\xEF\xBB\xBF") : '\x00-\x08\x0B\x0C\x0E-\x19\xA0') . ']+~' . ($context['utf8'] ? 'u' : ''), ' ', $_POST['realName']));
</replace>


<edit file>
$sourcedir/LogInOut.php
</edit file>

<search for>
* =============================================================================== *
* Software Version:           SMF 1.1.6                                           *
</search for>

<replace>
* =============================================================================== *
* Software Version:           SMF 1.1.19                                          *
</replace>

<search for>
	// Empty the cookie! (set it in the past, and for ID_MEMBER = 0)
	setLoginCookie(-3600, 0);
</search for>

<replace>
	// Empty the cookie! (set it in the past, and for ID_MEMBER = 0)
	setLoginCookie(-3600, 0);
	session_destroy();
	if (!empty($ID_MEMBER))
		updateMemberData($ID_MEMBER, array('passwordSalt' => '\'' . substr(md5(mt_rand()), 0, 4) . '\''));
</replace>


<edit file>
$sourcedir/Register.php
</edit file>

<search for>
* =============================================================================== *
* Software Version:           SMF 1.1.18                                          *
</search for>

<replace>
* =============================================================================== *
* Software Version:           SMF 1.1.19                                          *
</replace>

<search for>
		'signature', 'personalText', 'avatar',
</search for>

<replace>
		'personalText', 'avatar',
</replace>

<search for>
		$_POST['realName'] = trim(preg_replace('~[\s]~' . ($context['utf8'] ? 'u' : ''), ' ', $_POST['realName']));
</search for>

<replace>
		$_POST['realName'] = trim(preg_replace('~[\t\n\r \x0B\0' . ($context['utf8'] ? ($context['server']['complex_preg_chars'] ? '\x{A0}\x{AD}\x{2000}-\x{200F}\x{201F}\x{202F}\x{3000}\x{FEFF}' : "\xC2\xA0\xC2\xAD\xE2\x80\x80-\xE2\x80\x8F\xE2\x80\x9F\xE2\x80\xAF\xE2\x80\x9F\xE3\x80\x80\xEF\xBB\xBF") : '\x00-\x08\x0B\x0C\x0E-\x19\xA0') . ']+~' . ($context['utf8'] ? 'u' : ''), ' ', $_POST['realName']));
</replace>


<edit file>
$sourcedir/Subs-Members.php
</edit file>

<search for>
* =============================================================================== *
* Software Version:           SMF 1.1.15                                          *
</search for>

<replace>
* =============================================================================== *
* Software Version:           SMF 1.1.19                                          *
</replace>

<search for>
	$regOptions['username'] = preg_replace('~[\t\n\r\x0B\0' . ($context['utf8'] ? ($context['server']['complex_preg_chars'] ? '\x{A0}' : pack('C*', 0xC2, 0xA0)) : '\xA0') . ']+~' . ($context['utf8'] ? 'u' : ''), ' ', $regOptions['username']);
</search for>

<replace>
	$regOptions['username'] = trim(preg_replace('~[\t\n\r \x0B\0' . ($context['utf8'] ? ($context['server']['complex_preg_chars'] ? '\x{A0}\x{AD}\x{2000}-\x{200F}\x{201F}\x{202F}\x{3000}\x{FEFF}' : "\xC2\xA0\xC2\xAD\xE2\x80\x80-\xE2\x80\x8F\xE2\x80\x9F\xE2\x80\xAF\xE2\x80\x9F\xE3\x80\x80\xEF\xBB\xBF") : '\x00-\x08\x0B\x0C\x0E-\x19\xA0') . ']+~' . ($context['utf8'] ? 'u' : ''), ' ', $regOptions['username']));
</replace>


<edit file>
$sourcedir/Subs-Auth.php
</edit file>

<search for>
* =============================================================================== *
* Software Version:           SMF 1.1.11                                          *
</search for>

<replace>
* =============================================================================== *
* Software Version:           SMF 1.1.19                                          *
</replace>

<search for>
		$user = trim($username);
</search for>

<replace>
		$user = trim(preg_replace('~[\t\n\r \x0B\0' . ($context['utf8'] ? ($context['server']['complex_preg_chars'] ? '\x{A0}\x{AD}\x{2000}-\x{200F}\x{201F}\x{202F}\x{3000}\x{FEFF}' : "\xC2\xA0\xC2\xAD\xE2\x80\x80-\xE2\x80\x8F\xE2\x80\x9F\xE2\x80\xAF\xE2\x80\x9F\xE3\x80\x80\xEF\xBB\xBF") : '\x00-\x08\x0B\x0C\x0E-\x19\xA0') . ']+~' . ($context['utf8'] ? 'u' : ''), ' ', $username));
</replace>