[b][size=16pt][url=http://ahrasis.com][color=brown]Remove Re From Post Title[/color][/url][/size][/b]
Created by [url=http://ahrasis.com]ahrasis[/url]
For SMF 1.1.x and SMF 2.x


On default the every reply to a post will have a Re: in its post title.

This mod simply remove that at its best and will apply to all default user languages.

It's advisable to always do a backup before you run any mod.

Thank you for using it.


Yours friendly,
Abu Fahim Ismail.